package views;

import java.util.Scanner;

public class ExitMenu implements AppMenu{
    @Override
    public void checker(Scanner scanner) {

    }
}
