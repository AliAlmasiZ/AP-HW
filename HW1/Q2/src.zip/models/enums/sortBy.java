package models.enums;

public enum sortBy {
    RATE,
    HIGHER_PRICE_TO_LOWER,
    LOWER_PRICE_TO_HIGHER,
    NUMBER_OF_SOLDS;




}